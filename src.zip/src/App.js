import './App.css';
import Timer from './Timersetup.js';

function App() {
  return (
    <>
      <div className="App">
        <Timer />
      </div>
    </>
  );
}

export default App;
